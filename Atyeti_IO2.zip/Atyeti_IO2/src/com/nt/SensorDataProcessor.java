package com.nt;
import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

// Data Ingestion Module
class DataIngestion {
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static List<SensorData> readSensorData(String filePath) throws IOException {
        List<SensorData> sensorDataList = new ArrayList<>();
        List<String> lines = Files.readAllLines(Paths.get(filePath));
        for (String line : lines.subList(1, lines.size())) {
            String[] parts = line.split(",");
            if (parts.length != 5) {
                ErrorHandling.logError("ERR002: Invalid data format - " + line);
                continue;
            }
            try {
                LocalDate date = LocalDate.parse(parts[0], DATE_FORMATTER);
                int month = date.getMonthValue();
                sensorDataList.add(new SensorData(date, month, parts[1], Double.parseDouble(parts[2]), parts[3], parts[4]));
            } catch (Exception e) {
                ErrorHandling.logError("ERR002: Invalid data format - " + line);
            }
        }
        return sensorDataList;
    }
}

// Processing Module
class ProcessingModule {
    public static void generateMonthlyStatistics(List<SensorData> sensorDataList, String outputPath) throws IOException {
        Map<String, Map<Integer, List<Double>>> groupedData = sensorDataList.stream()
                .collect(Collectors.groupingBy(
                        s -> s.sensorType,
                        Collectors.groupingBy(
                                s -> s.month,
                                Collectors.mapping(s -> s.value, Collectors.toList())
                        )
                ));

        BufferedWriter writer = new BufferedWriter(new FileWriter(outputPath));
        writer.write("sensor_type,month,avg_value,max_value,min_value\n");
        for (Map.Entry<String, Map<Integer, List<Double>>> entry : groupedData.entrySet()) {
            for (Map.Entry<Integer, List<Double>> monthEntry : entry.getValue().entrySet()) {
                List<Double> values = monthEntry.getValue();
                double avg = values.stream().mapToDouble(Double::doubleValue).average().orElse(0);
                double max = values.stream().mapToDouble(Double::doubleValue).max().orElse(0);
                double min = values.stream().mapToDouble(Double::doubleValue).min().orElse(0);
                writer.write(String.format("%s,%d,%.2f,%.2f,%.2f\n", entry.getKey(), monthEntry.getKey(), avg, max, min));
            }
        }
        writer.close();
    }
}

// Outlier Detection Module
class OutlierDetection {
    public static void detectOutliers(List<SensorData> sensorDataList, Map<String, Threshold> thresholds, String outputPath) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(outputPath));
        writer.write("date,sensor_type,value,unit,location_id,threshold_exceeded\n");
        for (SensorData data : sensorDataList) {
            Threshold threshold = thresholds.get(data.sensorType);
            if (threshold == null) {
                ErrorHandling.logError("ERR004: Thresholds not defined for sensor - " + data.sensorType);
                continue;
            }
            if (data.value < threshold.minThreshold || data.value > threshold.maxThreshold) {
                String exceeded = data.value < threshold.minThreshold ? "Min" : "Max";
                writer.write(String.format("%s,%s,%.2f,%s,%s,%s\n", data.date, data.sensorType, data.value, data.unit, data.locationId, exceeded));
            }
        }
        writer.close();
    }
}

// Reporting Module
class ReportingModule {
    public static void generateReports(String monthlyStatsPath, String outliersPath) {
        System.out.println("Reports generated:");
        System.out.println("- " + monthlyStatsPath);
        System.out.println("- " + outliersPath);
    }
}

// Error Handling Module
class ErrorHandling {
    public static void logError(String message) {
        System.err.println(message);
    }
}

// Main Execution Class
public class SensorDataProcessor {
	private static final String SENSOR_DATA_FILE = "C:/Users/DayalkumarChand/Downloads/sensor_data.csv";
    private static final String THRESHOLDS_FILE = "C:/Users/DayalkumarChand/Downloads/thresholds.csv";
    private static final String MONTHLY_STATS_FILE = "C:/Users/DayalkumarChand/Downloads/monthly_stats.csv";
    private static final String OUTLIERS_FILE = "C:/Users/DayalkumarChand/Downloads/outliers.csv";

    public static void main(String[] args) {
        try {
            List<SensorData> sensorDataList = DataIngestion.readSensorData(SENSOR_DATA_FILE);
            Map<String, Threshold> thresholds = readThresholds();
            ProcessingModule.generateMonthlyStatistics(sensorDataList, MONTHLY_STATS_FILE);
            OutlierDetection.detectOutliers(sensorDataList, thresholds, OUTLIERS_FILE);
            ReportingModule.generateReports(MONTHLY_STATS_FILE, OUTLIERS_FILE);
        } catch (IOException e) {
            ErrorHandling.logError("ERR001: File not found - " + e.getMessage());
        } catch (Exception e) {
            ErrorHandling.logError("ERR003: Processing error - " + e.getMessage());
        }
    }

    private static Map<String, Threshold> readThresholds() throws IOException {
        Map<String, Threshold> thresholds = new HashMap<>();
        List<String> lines = Files.readAllLines(Paths.get(THRESHOLDS_FILE));
        for (String line : lines.subList(1, lines.size())) {
            String[] parts = line.split(",");
            if (parts.length != 3) {
                ErrorHandling.logError("ERR002: Invalid threshold format - " + line);
                continue;
            }
            thresholds.put(parts[0], new Threshold(Double.parseDouble(parts[1]), Double.parseDouble(parts[2])));
        }
        return thresholds;
    }
}
