package com.nt;

public class Threshold {
	public double minThreshold;
    public double maxThreshold;

    public Threshold(double minThreshold, double maxThreshold) {
        this.minThreshold = minThreshold;
        this.maxThreshold = maxThreshold;
    }
}
