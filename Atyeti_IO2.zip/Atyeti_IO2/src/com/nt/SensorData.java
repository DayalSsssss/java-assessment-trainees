package com.nt;

import java.time.LocalDate;

class SensorData {
    LocalDate date;
    int month;
    String sensorType;
    double value;
    String unit;
    String locationId;

    public SensorData(LocalDate date, int month, String sensorType, double value, String unit, String locationId) {
        this.date = date;
        this.month = month;
        this.sensorType = sensorType;
        this.value = value;
        this.unit = unit;
        this.locationId = locationId;
    }

    @Override
    public String toString() {
        return date + "," + month + "," + sensorType + "," + value + "," + unit + "," + locationId;
    }
}

